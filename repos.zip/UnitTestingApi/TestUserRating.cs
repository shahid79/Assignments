﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UnitTestingApi
{
    public class TestUserRating
    {
        public int Id { get; set; }

        public string username { get; set; }
        
        public int rating { get; set; }
        
        public string comments { get; set; }
    }
}
