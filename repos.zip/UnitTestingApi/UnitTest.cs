﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Testing;
using Newtonsoft.Json;
using WebAPI;
using Xunit;

namespace UnitTestingApi
{
    public class UnitTest : IClassFixture<WebApplicationFactory<Startup>>
    {
        private readonly HttpClient _httpClient; 
        public UnitTest(WebApplicationFactory<Startup> factory)
        {
            _httpClient = factory.CreateClient();


        }
        [Fact]
        public async Task HealthCheck_ReturnOk()
        {
            var response = await _httpClient.GetAsync("/healthcheck");
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }

        [Fact]
        public async Task Get_ReturnSuccessStatusCode()
        {
            var response = await _httpClient.GetAsync("/API");
            response.EnsureSuccessStatusCode();

        }

        [Fact]
        public async Task Get_ReturnExpectedMediaType()
        {
            var response = await _httpClient.GetAsync("/API");
            Assert.Equal("application/json", response.Content.Headers.ContentType.MediaType);


        }

        [Fact]
        public async Task Get_ReturnContent()
        {
            var response = await _httpClient.GetAsync("/API");
            Assert.NotNull(response.Content);

            Assert.Equal("application/json", response.Content.Headers.ContentType.MediaType);
            Assert.True(response.Content.Headers.ContentLength > 0);
        }

        [Fact]
        public async Task Post_EmailWrongAddress()
        {
            string url = "http://localhost:5000/API";
            TestUserRating testUserRating = new TestUserRating
            {
                Id = 1,
                username = "Salim",
                rating = 5,
                comments = "Don't Drink and Drive"
            };


            using (var content = new StringContent(JsonConvert.SerializeObject(testUserRating), System.Text.Encoding.UTF8, "application/json"))
            {
                var response = await _httpClient.PostAsync(url, content);

                Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
               

            }
        }

        }
    }


