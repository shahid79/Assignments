using System;

namespace WebAPI
{
    public class BeerNameId
    {
        public int id { get; set; }

        public string name { get; set; }

    }
}
