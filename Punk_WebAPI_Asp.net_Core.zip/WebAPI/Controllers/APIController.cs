﻿using System;
using System.Collections.Generic;
using System.IO;

using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class APIController : ControllerBase
    {
        private readonly ILogger<APIController> _logger;
        private  string url = "https://api.punkapi.com/v2/beers/";
        private readonly IWebHostEnvironment _hosting;


        public APIController(ILogger<APIController> logger,  IWebHostEnvironment hosting)
        {
            _logger = logger;
            _hosting = hosting;
        }


        

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] UserRating userrating)
        {
            // Save the weather...

            try

            {
                if (ModelState.IsValid)
                {


                    url += userrating.Id.ToString();

                    var httpClient = new HttpClient();


                    var response = await httpClient.GetAsync(url);

                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var beerNameIdList = JsonConvert.DeserializeObject<List<BeerNameId>>(apiResponse);

                    if (beerNameIdList.Count > 0)
                    {
                        UserRating newuserRating = new UserRating()
                        {
                            Id = userrating.Id,
                            username = userrating.username,
                            rating = userrating.rating,
                            comments = userrating.comments
                        };
                        
                        var filepath = Path.Combine(_hosting.ContentRootPath, "database.json");
                        var UserRatingList = new List<UserRating>();
                        var jsonFromFile = System.IO.File.ReadAllText(filepath);

                        if (jsonFromFile.Length > 0)
                        {
                        

                            var existingJson = JsonConvert.DeserializeObject<IEnumerable<UserRating>>(jsonFromFile);

                            UserRatingList = existingJson.ToList();

                        }


                        UserRatingList.Add(newuserRating);

                        string newJson = JsonConvert.SerializeObject(UserRatingList);

                        using (TextWriter tw = new StreamWriter(filepath, append: false))
                        {
                            tw.WriteLine(newJson);
                        };


                        return Ok();

                    }
                    else
                    {
                        return BadRequest(ModelState);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to save a new order: {ex}");
            }
            return BadRequest("Failed to Save as ID could not found");
        }

        [HttpGet]
        public async Task<List<DisplayRating>> Get()
        {
            string searchBeer = "";
            
            if ( (Request.Query["name"].ToString().Length > 0) )
            {

                searchBeer = Request.Query["name"];

            }


            List<UserRatingID> UserRatingIDList = new List<UserRatingID>();

            var httpClient = new HttpClient();


            var response = await httpClient.GetAsync(url);
                
            string apiResponse = await response.Content.ReadAsStringAsync();
            var userRatingIDList = JsonConvert.DeserializeObject<IEnumerable<UserRatingID>>(apiResponse);

            var userRatingIDFilterList = userRatingIDList.Where(n => n.name.Contains(searchBeer)).ToList();



            var filepath = Path.Combine(_hosting.ContentRootPath, "database.json");

            var existingJson = System.IO.File.ReadAllText(filepath);

            var UserRatingList = new List<UserRating>();

            var userRatings = JsonConvert.DeserializeObject<IEnumerable<UserRating>>(existingJson);

            UserRatingList = userRatings.ToList();



            IEnumerable<DisplayRating> displaRatings =
            from online in userRatingIDFilterList
            select new DisplayRating()
            {
                Id = online.Id,
                name = online.name,
                description = online.description,
                UserRatings = (UserRatingList.Where(i => i.Id == online.Id).ToList()).ToList()               
            };


            return displaRatings.ToList(); 


        }

    }
    

}
